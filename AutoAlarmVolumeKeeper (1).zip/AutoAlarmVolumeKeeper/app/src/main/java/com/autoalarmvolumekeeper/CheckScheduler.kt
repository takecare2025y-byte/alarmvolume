package com.autoalarmvolumekeeper

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.util.Log

/** Arms ONE check 10 minutes from now. Each check arms the next one (works in Doze). */
object CheckScheduler {
    private const val INTERVAL_MS = 10 * 60 * 1000L

    private fun pending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, CheckReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun canSchedule(ctx: Context): Boolean =
        ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    /** (Re)arms the next check if the keeper is ON; cancels it if OFF. Safe to call repeatedly. */
    fun schedule(ctx: Context) {
        if (!Prefs(ctx).enabled) {
            cancel(ctx)
            return
        }
        if (!canSchedule(ctx)) return
        try {
            ctx.getSystemService(AlarmManager::class.java).setExactAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + INTERVAL_MS,
                pending(ctx)
            )
        } catch (e: SecurityException) {
            Log.w("CheckScheduler", "Exact alarm not permitted", e)
        }
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx))
    }
}
