package com.autoalarmvolumekeeper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Fired every 10 minutes: arm the next check first, then check the alarm volume. */
class CheckReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Prefs(context).enabled) return
        CheckScheduler.schedule(context)
        VolumeKeeper.check(context)
    }
}
