package com.autoalarmvolumekeeper

import android.content.Context

/**
 * Tiny settings store. Uses device-protected storage so the check can be
 * re-armed after a reboot, before the first unlock.
 */
class Prefs(context: Context) {
    private val sp = context.createDeviceProtectedStorageContext()
        .getSharedPreferences("akv", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    /** Wanted alarm volume in percent (10..100). Default 100 = full. */
    var volume: Int
        get() = sp.getInt("volume", 100).coerceIn(10, 100)
        set(v) = sp.edit().putInt("volume", v.coerceIn(10, 100)).apply()

    var batteryTipShown: Boolean
        get() = sp.getBoolean("batteryTipShown", false)
        set(v) = sp.edit().putBoolean("batteryTipShown", v).apply()
}
