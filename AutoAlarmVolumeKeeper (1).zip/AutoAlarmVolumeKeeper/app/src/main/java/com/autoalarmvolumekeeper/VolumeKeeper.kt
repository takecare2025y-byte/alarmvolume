package com.autoalarmvolumekeeper

import android.content.Context
import android.media.AudioManager
import android.util.Log
import kotlin.math.roundToInt

/** The whole job of the app: if the ALARM volume is below the wanted level, raise it. */
object VolumeKeeper {

    /** Returns true if the volume was too low and has been raised. Only the alarm stream is touched. */
    fun check(context: Context): Boolean {
        val audio = context.getSystemService(AudioManager::class.java)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        val target = (max * Prefs(context).volume / 100f).roundToInt().coerceIn(1, max)
        if (audio.getStreamVolume(AudioManager.STREAM_ALARM) >= target) return false
        return try {
            audio.setStreamVolume(AudioManager.STREAM_ALARM, target, 0)
            true
        } catch (e: SecurityException) {
            Log.w("VolumeKeeper", "Alarm volume change refused by system", e)
            false
        }
    }
}
