package com.autoalarmvolumekeeper

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var keeperSwitch: Switch
    private lateinit var volumeLabel: TextView
    private lateinit var volumeSeek: SeekBar
    private lateinit var checkButton: Button

    private var binding = false          // true while we set the switch from code
    private var pendingEnable = false    // waiting for the user to come back from the exact-alarm settings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        // Edge-to-edge is enforced on Android 15+: keep content clear of system bars.
        findViewById<View>(R.id.scroll).setOnApplyWindowInsetsListener { v, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsets.CONSUMED
        }

        keeperSwitch = findViewById(R.id.keeperSwitch)
        volumeLabel = findViewById(R.id.volumeLabel)
        volumeSeek = findViewById(R.id.volumeSeek)
        checkButton = findViewById(R.id.checkButton)

        keeperSwitch.setOnCheckedChangeListener { _, on ->
            if (binding) return@setOnCheckedChangeListener
            if (on) tryEnable() else disable()
        }

        volumeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) prefs.volume = progress
                volumeLabel.text = getString(R.string.alarm_volume, progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                if (prefs.enabled) VolumeKeeper.check(this@MainActivity)
            }
        })

        // Manual test: lower the alarm volume in system settings, come back, tap this.
        checkButton.setOnClickListener {
            val raised = VolumeKeeper.check(this)
            Toast.makeText(this, if (raised) R.string.raised else R.string.already_ok, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        if (pendingEnable) {
            pendingEnable = false
            if (CheckScheduler.canSchedule(this)) tryEnable()
        }
        if (prefs.enabled) {
            if (CheckScheduler.canSchedule(this)) {
                CheckScheduler.schedule(this)   // self-heal: re-arm if the system dropped it
                VolumeKeeper.check(this)
            } else {
                prefs.enabled = false
                Toast.makeText(this, R.string.exact_revoked, Toast.LENGTH_LONG).show()
            }
        }
        refresh()
    }

    // ---- enable / disable ----------------------------------------------------------------

    private fun tryEnable() {
        if (!CheckScheduler.canSchedule(this)) {
            explain(R.string.perm_exact_msg) {
                pendingEnable = true
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
            return
        }
        prefs.enabled = true
        VolumeKeeper.check(this)
        CheckScheduler.schedule(this)
        maybeShowBatteryTip()
        refresh()
    }

    private fun disable() {
        prefs.enabled = false
        CheckScheduler.cancel(this)
        refresh()
    }

    private fun explain(message: Int, onOk: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton(android.R.string.ok) { _, _ -> onOk() }
            .setNegativeButton(android.R.string.cancel) { _, _ -> refresh() }
            .setOnCancelListener { refresh() }
            .show()
    }

    private fun maybeShowBatteryTip() {
        val pm = getSystemService(PowerManager::class.java)
        if (prefs.batteryTipShown || pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.batteryTipShown = true
        AlertDialog.Builder(this)
            .setMessage(R.string.battery_tip)
            .setPositiveButton(R.string.open_settings) { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: ActivityNotFoundException) { }
            }
            .setNegativeButton(R.string.not_now, null)
            .show()
    }

    private fun refresh() {
        binding = true
        keeperSwitch.isChecked = prefs.enabled
        binding = false
        volumeSeek.progress = prefs.volume
        volumeLabel.text = getString(R.string.alarm_volume, prefs.volume)
    }
}
