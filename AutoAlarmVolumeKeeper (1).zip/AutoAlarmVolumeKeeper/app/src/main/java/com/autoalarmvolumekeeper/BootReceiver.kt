package com.autoalarmvolumekeeper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the 10-minute checks after reboot, app update, or exact-alarm permission change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Prefs(context).enabled) return
        CheckScheduler.schedule(context)
        VolumeKeeper.check(context)
    }
}
