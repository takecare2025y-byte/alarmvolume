# Auto Alarm Volume Keeper (v1.1)

Tiny native Android app (Kotlin, no libraries). It plays **no sound**. Its only job: when the
switch is ON, about every 10 minutes it checks the phone's ALARM volume and, if it is lower than
the level you chose (default 100 %), raises it back.

* Android 12-16 (`minSdk 31`, `targetSdk 36`)
* Switch ON/OFF, volume slider (10-100 %), "Check now" button (manual test)

## How it works

* `CheckScheduler` arms one exact alarm (`setExactAndAllowWhileIdle`, 10 minutes ahead).
* `CheckReceiver` fires, arms the next one, then calls `VolumeKeeper.check()`.
* `VolumeKeeper.check()` reads `STREAM_ALARM`; if below target it calls
  `AudioManager.setStreamVolume(STREAM_ALARM, target, 0)`. Public API only.
* `BootReceiver` restarts the chain after reboot / app update / permission change.
* Switch OFF cancels everything; nothing runs.

## Permissions

| Permission | Why |
|---|---|
| `SCHEDULE_EXACT_ALARM` | Run the check every 10 minutes, also while idle (user grants it under "Alarms & reminders") |
| `RECEIVE_BOOT_COMPLETED` | Restart the checks after reboot |

No internet, storage, notifications, location, contacts or microphone.

## Limits

* If you lower the alarm volume on purpose, it is raised again at the next check (about 10 min).
* Only the alarm volume is changed (not media / ringtone / notification volume).
* Cannot override Do Not Disturb, manufacturer sound management, or headphone safety limits.
* Phones may delay or stop background work to save battery: set the app to *Unrestricted*.
* The 10-minute interval is approximate (Android may delay alarms slightly in Doze).

## Build

JDK 17 + Android SDK 36. `gradle assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`.
Release: see `keystore.properties` handling in `app/build.gradle.kts`, then `gradle assembleRelease`.
On GitHub: use the `build.yml` workflow (builds debug APK, optional signed release).

## Install / test

1. Uninstall any older version first (debug builds from different machines use different keys).
2. Install the APK, open the app, switch ON, allow "Alarms & reminders" when asked.
3. In system sound settings lower the **Alarm** volume, return to the app, tap **Check now**:
   the volume goes up. Or wait ~10 minutes with the switch ON.
4. Reboot the phone: checks restart on their own.
