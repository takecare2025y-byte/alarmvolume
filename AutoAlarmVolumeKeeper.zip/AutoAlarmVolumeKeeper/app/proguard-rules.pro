# Nothing needed: no reflection, no third-party libraries.
# Manifest components are kept automatically by the Android Gradle Plugin.
