package com.autoalarmvolumekeeper

import android.content.Context

/**
 * Tiny settings store. Uses device-protected storage so the alarm can be
 * re-armed (and can ring) after a reboot, before the first unlock.
 */
class Prefs(context: Context) {
    private val sp = context.createDeviceProtectedStorageContext()
        .getSharedPreferences("akv", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    /** Alarm volume in percent (10..100). Default 100. */
    var volume: Int
        get() = sp.getInt("volume", 100).coerceIn(10, 100)
        set(v) = sp.edit().putInt("volume", v.coerceIn(10, 100)).apply()

    var hour: Int
        get() = sp.getInt("hour", 7)
        set(v) = sp.edit().putInt("hour", v).apply()

    var minute: Int
        get() = sp.getInt("minute", 0)
        set(v) = sp.edit().putInt("minute", v).apply()

    var notifAsked: Boolean
        get() = sp.getBoolean("notifAsked", false)
        set(v) = sp.edit().putBoolean("notifAsked", v).apply()

    var batteryTipShown: Boolean
        get() = sp.getBoolean("batteryTipShown", false)
        set(v) = sp.edit().putBoolean("batteryTipShown", v).apply()
}
