package com.autoalarmvolumekeeper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/** Fired by AlarmManager at the alarm time: start ringing, then arm tomorrow's alarm. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Prefs(context).enabled) return
        try {
            context.startForegroundService(
                Intent(context, AlarmService::class.java).setAction(AlarmService.ACTION_START)
            )
        } catch (e: Exception) {
            Log.e("AlarmReceiver", "Could not start alarm service", e)
        }
        AlarmScheduler.schedule(context) // next day
    }
}
