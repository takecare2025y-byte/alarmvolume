package com.autoalarmvolumekeeper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Re-arms the alarm after reboot, app update, clock/timezone change, or exact-alarm permission change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Prefs(context).enabled) AlarmScheduler.schedule(context)
    }
}
