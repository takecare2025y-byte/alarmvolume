package com.autoalarmvolumekeeper

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.format.DateFormat
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var alarmSwitch: Switch
    private lateinit var timeButton: Button
    private lateinit var volumeLabel: TextView
    private lateinit var volumeSeek: SeekBar
    private lateinit var testButton: Button

    private var binding = false          // true while we set the switch from code
    private var pendingEnable = false    // waiting for the user to come back from the exact-alarm settings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        // Edge-to-edge is enforced on Android 15+: keep content clear of system bars.
        findViewById<View>(R.id.scroll).setOnApplyWindowInsetsListener { v, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsets.CONSUMED
        }

        alarmSwitch = findViewById(R.id.alarmSwitch)
        timeButton = findViewById(R.id.timeButton)
        volumeLabel = findViewById(R.id.volumeLabel)
        volumeSeek = findViewById(R.id.volumeSeek)
        testButton = findViewById(R.id.testButton)

        alarmSwitch.setOnCheckedChangeListener { _, on ->
            if (binding) return@setOnCheckedChangeListener
            if (on) tryEnable() else disable()
        }

        timeButton.setOnClickListener {
            TimePickerDialog(
                this,
                { _, h, m ->
                    prefs.hour = h
                    prefs.minute = m
                    if (prefs.enabled) AlarmScheduler.schedule(this)
                    refresh()
                },
                prefs.hour, prefs.minute, DateFormat.is24HourFormat(this)
            ).show()
        }

        volumeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) prefs.volume = progress
                volumeLabel.text = getString(R.string.alarm_volume, progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        testButton.setOnClickListener {
            val svc = Intent(this, AlarmService::class.java)
            if (AlarmService.ringing) {
                startService(svc.setAction(AlarmService.ACTION_STOP))
            } else {
                startForegroundService(svc.setAction(AlarmService.ACTION_TEST))
            }
        }
    }

    override fun onStart() {
        super.onStart()
        AlarmService.listener = { refresh() }
    }

    override fun onStop() {
        AlarmService.listener = null
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (pendingEnable) {
            pendingEnable = false
            if (AlarmScheduler.canSchedule(this)) tryEnable()
        }
        if (prefs.enabled) {
            if (AlarmScheduler.canSchedule(this)) {
                AlarmScheduler.schedule(this)   // self-heal: re-arm if the system dropped it
            } else {
                prefs.enabled = false
                Toast.makeText(this, R.string.exact_revoked, Toast.LENGTH_LONG).show()
            }
        }
        refresh()
    }

    // ---- enable / disable flow (each permission is explained before it is requested) -----

    private fun tryEnable() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !prefs.notifAsked
        ) {
            explain(R.string.perm_notif_msg) {
                prefs.notifAsked = true
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            return
        }
        if (!AlarmScheduler.canSchedule(this)) {
            explain(R.string.perm_exact_msg) {
                pendingEnable = true
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
            return
        }
        prefs.enabled = true
        AlarmScheduler.schedule(this)
        maybeShowBatteryTip()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        tryEnable() // continue even if notifications were denied; the alarm itself still works
    }

    private fun disable() {
        prefs.enabled = false
        AlarmScheduler.cancel(this)
        refresh()
    }

    private fun explain(message: Int, onOk: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton(android.R.string.ok) { _, _ -> onOk() }
            .setNegativeButton(android.R.string.cancel) { _, _ -> refresh() }
            .setOnCancelListener { refresh() }
            .show()
    }

    private fun maybeShowBatteryTip() {
        val pm = getSystemService(PowerManager::class.java)
        if (prefs.batteryTipShown || pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.batteryTipShown = true
        AlertDialog.Builder(this)
            .setMessage(R.string.battery_tip)
            .setPositiveButton(R.string.open_settings) { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: ActivityNotFoundException) { }
            }
            .setNegativeButton(R.string.not_now, null)
            .show()
    }

    // ---- UI state ------------------------------------------------------------------------

    private fun refresh() {
        binding = true
        alarmSwitch.isChecked = prefs.enabled
        binding = false

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, prefs.hour)
            set(Calendar.MINUTE, prefs.minute)
        }
        timeButton.text = getString(R.string.alarm_time, DateFormat.getTimeFormat(this).format(cal.time))

        volumeSeek.progress = prefs.volume
        volumeLabel.text = getString(R.string.alarm_volume, prefs.volume)
        testButton.setText(if (AlarmService.ringing) R.string.stop_alarm else R.string.test_alarm)
    }
}
