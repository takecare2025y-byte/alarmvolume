package com.autoalarmvolumekeeper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import kotlin.math.roundToInt

/**
 * Plays the alarm and protects its loudness.
 *
 * The alarm-stream volume is touched ONLY while this service is ringing:
 *  1. on start  -> remember the current alarm volume, set the chosen level
 *  2. every second while ringing -> if the alarm stream got quieter than the chosen level, restore it
 *  3. on stop   -> put the user's previous alarm volume back
 * When nothing is ringing this service is not running and nothing is changed.
 */
class AlarmService : Service() {

    companion object {
        const val ACTION_START = "com.autoalarmvolumekeeper.START"
        const val ACTION_TEST = "com.autoalarmvolumekeeper.TEST"
        const val ACTION_STOP = "com.autoalarmvolumekeeper.STOP"

        private const val TAG = "AlarmService"
        private const val CHANNEL_ID = "alarm"
        private const val NOTIF_ID = 1
        private const val GUARD_INTERVAL_MS = 1000L
        private const val MAX_RING_MS = 10 * 60 * 1000L   // scheduled alarm stops itself after 10 min
        private const val TEST_RING_MS = 30 * 1000L       // test alarm stops itself after 30 s

        @Volatile
        var ringing = false
            private set

        /** Set by the UI so the button label follows the ringing state. Always called on the main thread. */
        var listener: (() -> Unit)? = null
    }

    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var audio: AudioManager
    private var player: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null
    private var targetIndex = 0
    private var savedIndex = -1

    private val guard = object : Runnable {
        override fun run() {
            if (audio.getStreamVolume(AudioManager.STREAM_ALARM) < targetIndex) {
                setAlarmVolume(targetIndex)
            }
            handler.postDelayed(this, GUARD_INTERVAL_MS)
        }
    }
    private val autoStop = Runnable { stopRinging() }

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(AudioManager::class.java)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopRinging()
            return START_NOT_STICKY
        }
        if (action == ACTION_START || action == ACTION_TEST) {
            showForeground() // must be called promptly after startForegroundService()
            if (!ringing) beginRinging(if (action == ACTION_TEST) TEST_RING_MS else MAX_RING_MS)
        } else {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    // ---- ringing -------------------------------------------------------------------------

    private fun beginRinging(durationMs: Long) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        targetIndex = (max * Prefs(this).volume / 100f).roundToInt().coerceIn(1, max)
        savedIndex = audio.getStreamVolume(AudioManager.STREAM_ALARM)
        setAlarmVolume(targetIndex)

        focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .build()
            .also { audio.requestAudioFocus(it) }

        if (!startPlayer()) {
            Log.e(TAG, "No playable alarm sound found")
            stopRinging()
            return
        }
        ringing = true
        listener?.invoke()
        handler.postDelayed(guard, GUARD_INTERVAL_MS)
        handler.postDelayed(autoStop, durationMs)
    }

    private fun startPlayer(): Boolean {
        val candidates = listOfNotNull(
            runCatching { RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM) }.getOrNull(),
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        )
        for (uri in candidates) {
            val mp = MediaPlayer()
            try {
                mp.setAudioAttributes(attrs)
                mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                mp.setDataSource(applicationContext, uri)
                mp.isLooping = true
                mp.setVolume(1f, 1f)
                mp.prepare()
                mp.start()
                player = mp
                return true
            } catch (e: Exception) {
                Log.w(TAG, "Could not play $uri", e)
                mp.release()
            }
        }
        return false
    }

    private fun setAlarmVolume(index: Int) {
        try {
            audio.setStreamVolume(AudioManager.STREAM_ALARM, index, 0)
        } catch (e: SecurityException) {
            Log.w(TAG, "Alarm volume change refused by system", e)
        }
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        player?.let {
            try { it.stop() } catch (_: IllegalStateException) { }
            it.release()
        }
        player = null
        focus?.let { audio.abandonAudioFocusRequest(it) }
        focus = null
        if (savedIndex >= 0) {            // give the user's own alarm volume back
            setAlarmVolume(savedIndex)
            savedIndex = -1
        }
        if (ringing) {
            ringing = false
            listener?.invoke()
        }
    }

    private fun stopRinging() {
        cleanup()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---- notification --------------------------------------------------------------------

    private fun showForeground() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_alarm)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_alarm), getString(R.string.stop), stop
                ).build()
            )
            .setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
        startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    }
}
