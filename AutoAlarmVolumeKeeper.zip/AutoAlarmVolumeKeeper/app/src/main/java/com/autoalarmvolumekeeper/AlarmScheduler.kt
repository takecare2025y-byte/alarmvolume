package com.autoalarmvolumekeeper

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import java.time.ZonedDateTime

/** Schedules ONE daily alarm with AlarmManager.setAlarmClock (exact, Doze-exempt). */
object AlarmScheduler {
    private const val TAG = "AlarmScheduler"

    private fun fireIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, AlarmReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun showIntent(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 2, Intent(ctx, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun canSchedule(ctx: Context): Boolean =
        ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    /** (Re)arms the next occurrence if the alarm is ON; cancels it if OFF. Safe to call repeatedly. */
    fun schedule(ctx: Context) {
        val prefs = Prefs(ctx)
        if (!prefs.enabled) {
            cancel(ctx)
            return
        }
        if (!canSchedule(ctx)) return
        val am = ctx.getSystemService(AlarmManager::class.java)
        try {
            am.setAlarmClock(
                AlarmManager.AlarmClockInfo(nextTriggerMillis(prefs.hour, prefs.minute), showIntent(ctx)),
                fireIntent(ctx)
            )
        } catch (e: SecurityException) {
            Log.w(TAG, "Exact alarm not permitted", e)
        }
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(fireIntent(ctx))
    }

    private fun nextTriggerMillis(hour: Int, minute: Int): Long {
        val now = ZonedDateTime.now()
        var t = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if (!t.isAfter(now)) t = t.plusDays(1)
        return t.toInstant().toEpochMilli()
    }
}
