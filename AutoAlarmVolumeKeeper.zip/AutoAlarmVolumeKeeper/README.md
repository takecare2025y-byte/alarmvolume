# Auto Alarm Volume Keeper

A tiny native Android app (Kotlin, no third-party libraries) with one job: its **own** alarm
never ends up too quiet.

* Android 12-16 (`minSdk 31`, `targetSdk 36`)
* One ON/OFF switch, one volume slider (10-100 %, default 100 %), one test button
* One extra control, the daily alarm time, because a scheduled alarm needs a time

## How the volume protection works

The alarm-stream volume is touched **only while the app's alarm is ringing** (`AlarmService`):

1. Alarm starts: the current alarm volume is remembered and the chosen level is set
   (`AudioManager.setStreamVolume(STREAM_ALARM, ...)`, public API).
2. While ringing, once per second: if `getStreamVolume(STREAM_ALARM)` is below the chosen
   level, it is set back.
3. Alarm stops (Stop button, 10-minute timeout, or 30 s for the test): the user's previous
   alarm volume is restored, the check loop ends and the service exits.

Nothing runs and nothing is changed when no alarm is ringing.

## How the alarm is scheduled

* `AlarmManager.setAlarmClock()`: exact, exempt from Doze, shows the system alarm icon.
* `AlarmReceiver` starts the foreground service (`mediaPlayback` type) and arms tomorrow's alarm.
* `BootReceiver` re-arms after reboot (including before first unlock: settings live in
  device-protected storage), app update, clock/timezone change.
* `MainActivity.onResume` re-arms if the system dropped the alarm.
* Sound: the phone's default alarm ringtone (nothing bundled, so the APK stays small).

## Permissions (all explained in the app)

| Permission | Why |
|---|---|
| `SCHEDULE_EXACT_ALARM` (Android 12-13) / `USE_EXACT_ALARM` (13+) | Ring at the exact minute |
| `POST_NOTIFICATIONS` (13+) | Ringing notification with a Stop button (optional: alarm works without it) |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | Keep playing with the screen off |
| `WAKE_LOCK` | Keep the CPU awake while the alarm plays |
| `RECEIVE_BOOT_COMPLETED` | Re-arm the alarm after reboot |

No internet, storage, location, contacts or microphone access. No hidden APIs.
`REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` is deliberately **not** requested; the app offers a
link to the system battery settings instead.

## Limitations (also shown in the app)

* It does not control alarms from other apps.
* It cannot override Do Not Disturb, manufacturer sound management, or headphone
  volume-safety limits. Some phones apply their own rules.
* Hardware volume buttons: while the alarm rings, the app may raise the volume again.
  Use **Stop** to silence it.
* Some manufacturers kill background apps aggressively. If the alarm ever fails to ring,
  set the app's battery usage to *Unrestricted*.
* If the app's sound cannot be played at all, the alarm is silent. Choose a valid default
  alarm sound in the system sound settings.

## Build

Requirements: **JDK 17**, **Android SDK 36** (Android Studio Koala or newer is easiest).

### Open in Android Studio
`File > Open` the project folder, let Gradle sync (it downloads Gradle 8.11.1, the Android Gradle
Plugin 8.9.1 and Kotlin 2.1.0). If Studio offers to upgrade the plugin versions, that's fine.

### Command line
The Gradle wrapper JAR is not included. Generate it once (needs Gradle installed), or just
use Android Studio:

```
gradle wrapper --gradle-version 8.11.1
```

**Debug APK** (signed with the debug key, installable immediately):

```
./gradlew assembleDebug
# -> app/build/outputs/apk/debug/app-debug.apk
```

**Release APK** (minified, resources shrunk, must be signed to be installable):

1. Create a keystore once:
   ```
   keytool -genkeypair -v -keystore release.jks -alias akv -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Create `keystore.properties` in the project root (both files are git-ignored):
   ```
   storeFile=release.jks
   storePassword=YOUR_STORE_PASSWORD
   keyAlias=akv
   keyPassword=YOUR_KEY_PASSWORD
   ```
3. Build:
   ```
   ./gradlew assembleRelease
   # -> app/build/outputs/apk/release/app-release.apk
   ```
   Without `keystore.properties` you get `app-release-unsigned.apk`; sign it with
   `apksigner sign --ks release.jks app-release-unsigned.apk`.

Android Studio equivalent: *Build > Generate Signed App Bundle / APK > APK*.

Keep the keystore safe: updates must be signed with the same key.

Note on Google Play: `USE_EXACT_ALARM` is restricted to alarm-clock/calendar apps and needs
a Play Console declaration. For sideloading this doesn't matter.

## Install

* USB: enable *Developer options > USB debugging*, then
  `adb install -r app/build/outputs/apk/debug/app-debug.apk`
* Or copy the APK to the phone and open it (allow "Install unknown apps" for your file manager).

## Test checklist

1. **Test button**: tap *Test alarm*. The default alarm sound plays at your chosen volume,
   a notification with *Stop* appears, it stops after 30 s or on *Stop*.
2. **Recovery**: while the test rings, open the system volume panel and lower *Alarm* volume.
   Within about a second the app raises it back. After stopping, check your original alarm
   volume is restored.
3. **Scheduled alarm**: turn the switch ON (accept the permission explanations), set the time
   2 minutes ahead, lock the phone. It should ring on time, with the screen off.
4. **Reboot**: with the alarm ON, restart the phone and confirm it still rings
   (`adb shell dumpsys alarm | grep autoalarmvolumekeeper` should list a pending alarm clock).
5. **Battery**: put the phone to sleep for 30+ minutes before the alarm time (Doze test).
6. **Permission revoke** (Android 14+): remove *Alarms & reminders* for the app in system
   settings, reopen the app: the switch turns itself OFF with an explanation.
7. **Do Not Disturb**: DND normally lets alarms through; if your DND setup silences alarms,
   the app can't change that.

## Project layout

```
app/src/main/java/com/autoalarmvolumekeeper/
  MainActivity.kt     UI: switch, time, volume slider, test button, permission explanations
  AlarmService.kt     foreground service: plays sound, keeps volume, restores on stop
  AlarmScheduler.kt   setAlarmClock scheduling (next daily occurrence)
  AlarmReceiver.kt    alarm fired -> start service, arm tomorrow
  BootReceiver.kt     re-arm after reboot / update / time change
  Prefs.kt            settings (device-protected storage)
app/src/main/AndroidManifest.xml
app/build.gradle.kts, build.gradle.kts, settings.gradle.kts
```
